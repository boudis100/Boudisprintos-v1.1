# BoudisprintOS v1.1 – Lokální instalace

## Postup:
1. Nahraj celý tento balíček do Raspberry Pi (např. přes WinSCP nebo USB).
2. V terminálu spusť:
```bash
chmod +x build_boudisprintos.sh
./build_boudisprintos.sh
```
3. Skript automaticky:
- Nainstaluje Klipper, Moonraker, Fluidd
- Nahraje konfigurace a téma
- Aktivuje startovací zvuk

✅ Po restartu bude BoudisprintOS plně funkční.
