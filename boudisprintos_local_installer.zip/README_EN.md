# BoudisprintOS v1.1 – Local Installer

## Instructions:
1. Upload this package to your Raspberry Pi (e.g., via WinSCP or USB).
2. Run in terminal:
```bash
chmod +x build_boudisprintos.sh
./build_boudisprintos.sh
```
3. The script will:
- Install Klipper, Moonraker, Fluidd
- Load your config files and custom theme
- Enable startup sound

✅ After reboot, BoudisprintOS will be fully running.
