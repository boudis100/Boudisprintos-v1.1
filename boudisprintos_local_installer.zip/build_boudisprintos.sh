#!/bin/bash
set -e

echo "🛠️ Začíná instalace BoudisprintOS v1.1..."

# Instalace Klipper
if [ ! -d ~/klipper ]; then
  git clone https://github.com/Klipper3d/klipper.git ~/klipper
fi

# Instalace Moonraker
if [ ! -d ~/moonraker ]; then
  git clone https://github.com/Arksine/moonraker.git ~/moonraker
fi

# Instalace Fluidd
if [ ! -d ~/fluidd ]; then
  git clone https://github.com/fluidd-core/fluidd.git ~/fluidd
fi

# Vytvoření složky config
mkdir -p ~/printer_data/config
cp -r ./config/* ~/printer_data/config/
cp ./assets/* ~/printer_data/config/

# Povolení startup zvuku
sudo cp ~/printer_data/config/boudisprintos_startup.service /etc/systemd/system/
sudo systemctl enable boudisprintos_startup.service

chmod +x ~/printer_data/config/boudisprintos_startup.sh

echo "✅ Instalace dokončena. Restartujte Raspberry Pi pro plné spuštění."
